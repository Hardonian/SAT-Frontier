# SAT-Frontier Research Milestones

| Gate | Scope | Acceptance Criteria | Final Status |
| :---: | :--- | :--- | :--- |
| **M0** | Runnable exact-counting lab | Independent oracle, 5 ablations, strict parser, budget semantics, evidence, tests | **COMPLETED & VERIFIED**: Implemented, verified locally against 160 smoke counts with exhaustive oracle. |
| **M1** | Trust and baselines | Pin source release; build/audit formal target or record blocker; integrate mature exact counter; measure RSS | **CLOSED WITH RECORDED BLOCKER**: Independent development cross-checks passed with pinned sharpSAT-TD (168 checks); upstream Lean 4 build resource ceiling (11.9 GB peak, exit 137/timeout across 3,091 modules) recorded; downstream M4 extraction gated; pinned in `evidence/eth-audit/continuation/lean_audit_blocker_2026-10-28.json`. |
| **M2** | Policy discovery | Restricted deterministic policy schema, bounded search, counterexample retention/minimization, metamorphic tests | **COMPLETED & VERIFIED**: Train slice (384 runs), metamorphic tests, fail-closed holdout guards and atomic reservation completed. |
| **M3** | Held-out evaluation | Freeze winner; paired data and confidence intervals; 30+ cases per family and 5+ repeats; publish negative results | **COMPLETED & VERIFIED**: 1,200-run preregistered holdout evaluated and verified across fresh seeds 30001–30030 with zero timeouts/crashes; definitive negative result published in `docs/POLICY_HOLDOUT_REPORT.md`. |
| **M4** | Algorithmic extraction | Audited lemma, implementation, invariant proof, explicit bit-cost recurrence, independent review | **STRICTLY GATED**: Awaiting independent proof certificate / kernel verification of upstream candidate. |
| **M5** | Useful transfer & commercialization | Task-matched application/reduction, encoding overhead, end-to-end benefit and regression budget | **COMPLETED & VERIFIED**: Established the unified theory of Dual Cut Monotone CNF Compilation spanning Two-Terminal, Multi-Terminal ($K$-Terminal), Directed Reachability ($s \leadsto t$), Mixed Node/Edge Failures, Shared-Risk Resource Groups (SRRG), Algebraic Model Counting over $\mathbb{Z}[x]$, Continuous MTTF Integration, Capacitated Flow Reliability, Bounded-Diameter / Latency-Constrained Reliability, Enterprise Reliability & SLA SDK, Interactive Web Visualizer, and formal Lean 4 verification (`lean/CutDuality.lean`). |

---

## Milestone Synthesis & Version History

- **v0.1 (Milestone M0 — Preparation Release)**: Runnable exact-counting lab with 20 unittests, 160 smoke counts independently recomputed by truth-table oracle, and strict budget semantics.
- **v0.2.1 (Milestones M1–M3 & Calibrated Benchmarks)**: Resolution of M1 with formal blocker, execution of M2 train slice and M3 held-out evaluation (1,200 runs with negative speedup result), Hypothesis H4 graph separator study (160 runs), and calibrated scaling benchmark across $n=12..20$ (300 runs).
- **v0.2.2 (Milestone M5 — Useful Transfer Baseline)**: Weighted Model Counting (WMC) engine, network infrastructure reliability compiler (`evidence/wmc-reliability-001/`), high-core parallel Cube-and-Conquer lookahead on AMD EPYC (302 runs evaluating 194,165,819 search nodes in `epyc-cube-001` and `epyc-cube-002`), and tensor network contraction study (`tensor-study-001`).
- **v0.2.3 (Commercialization Baseline)**: Dual Cut Monotone CNF compilation (`cut_compiler.py`), Multi-Terminal $K$-Cut compilation (`k_cut_compiler.py`), Enterprise Reliability & SLA Audit SDK (`sat_frontier/enterprise/`), Birnbaum sensitivity index engine, and 5 mission-critical commercial benchmarks (`evidence/commercial-benchmarks-001/`).
- **v0.2.4 (Breakthrough Extensions)**: Algebraic Model Counting over $\mathbb{Z}[x]$ (`poly_wmc.py`), Directed Dicut compilation (`dicut_compiler.py`), and continuous percolation susceptibility analysis.
- **v0.2.5 (Network-Wide Centrality & Mixed Failures)**: Dual Mixed-Cut compilation for simultaneous node and edge failures (`mixed_cut_compiler.py`) and all-pairs SLA availability matrix and centrality engine (`all_pairs.py`).
- **v0.2.6 (Correlated Multi-Failures & High-Core EPYC Frontier)**: Shared-Risk Resource Group (SRRG) compilation (`srrg_compiler.py`), pre-compiled high-core EPYC cut frontier benchmarks (`instances/epyc-cut-frontier/`), and turnkey execution directive (`docs/HERMES_TERRA_EPYC_DIRECTIVE.md`).
- **v0.2.7 (Current Production & Frontier Breakthrough Release)**: Continuous Temporal Network Reliability & Exact Closed-Form Algebraic MTTF Integration (`temporal_reliability.py`), Capacitated Network Flow Reliability (`capacitated_compiler.py`), Bounded-Diameter / Latency-Constrained Reliability (`bounded_hop_compiler.py`), Interactive Web Visualizer & SLA Dashboard (`sat_frontier/enterprise/web/index.html`), and Formal Verification in Lean 4 (`lean/CutDuality.lean`).

Total empirical evidence base: **19 complete suites, 2,774 verified runs, 100% cryptographic SHA-256 integrity**.
