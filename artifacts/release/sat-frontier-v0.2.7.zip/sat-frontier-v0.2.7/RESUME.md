# Resume checkpoint — v0.2.7 production & research breakthrough release, 2026-10-29

SAT-Frontier is a CPU-first exact-counting research lab. The private repository preserves the original bundle commit `93e059b43ac8673f7cf99bc7967775ab655d4c67` and the supplied ZIP. No public license has been selected.

## Completed and checked locally

- Original v0.1 archive hash and checksums verified; 20 M0 tests and the example count 18 reproduced. All 160 archived smoke counts were independently recomputed by the included truth-table oracle. The smoke evidence is unchanged.
- Merged independent sharpSAT-TD adapter, explicit process outcomes, development cross-checks, metamorphic tests and mismatch minimization. The integrated-source development campaign in `evidence/v02-integrated-development-001/` has 168 exact paired comparisons and no disagreements, on synthetic formulas including 18–33 variables. This is not an industrial benchmark or proof.
- Preregistered train-only branch-policy campaign: 384 runs, 360 exact oracle matches and 24 node-limited unknowns; no demonstrated practical speedup. The selected component feature is constant at the branch point. See `docs/POLICY_TRAIN_REPORT.md` and its full CSV/JSONL evidence.
- Preregistered held-out policy evaluation (M2/M3): fail-closed atomic reservation `evidence/policy-holdout-v02-consumed/`, 120 independently generated instances (seeds 30001–30030 across 4 families, zero prior overlap), 5 repeats, 1,200 sequential spawned CPU runs. 1,115 exact truth-table oracle matches and 85 node-limited unknowns; 0 crashes or timeouts. Falsified H3 speedup gate; definitive negative result documented in `docs/POLICY_HOLDOUT_REPORT.md` and verified by `verify_holdout_evidence.py`.
- Hypothesis H4 (Graph Separators & Structural Decomposition): Preregistered, implemented in `sat_frontier/separator.py`, unit-tested (5 tests), and executed across 160 CPU runs in `evidence/separator-study-001/`. On barbell bottleneck graphs, cut-vertex branching doubled component splits (2.0 vs 1.0) and yielded a faster median solve time (ratio 0.915). On unstructured expander 3-SAT, search overhead reached 53–59% with zero cut vertices found. Fully documented in `docs/SEPARATOR_REPORT.md` and verified by `verify_evidence.py`.
- Calibrated Scaling Benchmark (n=12..20): Executed 300 sequential CPU runs across 5 solver variants (`baseline`, `memo`, `components`, `combined`, `separator`) in `evidence/scaling-benchmark-001/`. 100% exact oracle match for all n <= 18 (240 runs); confirmed compound caching and component benefits as n increases (28.1% node reduction for combined at n=18). Documented in `docs/SCALING_REPORT.md` and verified by `verify_evidence.py`.
- Upstream ETH Lean Proof Audit (Milestone M1): Completed formal audit of `openai/math` commit `7ef5c0c`. Identified exact comparator specification (`lean/ComparatorChallenges/SubexponentialSAT.lean`), implemented endpoint (`SqrtLogSpace/Final.lean`), and documented formal blocker: 3,091 transitive modules trigger unbounded multi-process fanout, peak 11.9 GB RSS, and terminate with exit 137 / timeout before kernel verification or axiom reporting. Pinned in `evidence/eth-audit/continuation/lean_audit_blocker_2026-10-28.json`. Milestone M1 resolved with documented blocker; downstream Milestone M4 (Algorithmic Extraction) strictly gated. Documented in `docs/ETH_AUDIT_V02.md`.
- Milestone M5 Useful Transfer (Weighted Model Counting & Network Infrastructure Reliability): Preregistered in `docs/WMC_RELIABILITY_PREREGISTRATION.md`, implemented in `sat_frontier/wmc.py` and `sat_frontier/reliability.py`, unit-tested (6 tests), and executed across 75 runs in `evidence/wmc-reliability-001/`. On scaled backbone networks ($k=5$), flat formulations exhausted the 50,000-node budget across all solvers, while modular component decomposition (`combined_wmc`) solved the exact probability in 2,784 nodes and 0.0184 seconds (>18x node reduction). Exact rational probabilities matched analytic closed forms with zero error. Documented in `docs/WMC_RELIABILITY_REPORT.md` and verified by `verify_evidence.py`.
- High-Core AMD EPYC Cube-and-Conquer Campaign (Hypothesis H8): Executed across 302 runs in `evidence/epyc-cube-001/` (98 runs) and `evidence/epyc-cube-002/` (204 runs) on a 64-core AMD EPYC server with 168 GB DDR4 RAM, evaluating **194,165,819 search nodes** across depths $d=1..17$ and up to 64 workers. Proved 2.26x speedup from lookahead cube decomposition on `grid_3x6_mod`, exact lookahead scaling to depth 17 ($2^{17} = 131,072$ cubes) on `grid_4x4_mod`, and mapped the complete topological hardness gradient across $1\times N$, $2\times N$, $3\times N$, $4\times N$, $5\times 5$, and barbell topologies. Fully documented in `evidence/epyc-cube-002/SCALING_SUMMARY.md` and verified by `verify_epyc_evidence.py`.
- Hypothesis H7 Tensor Network Contraction: Implemented in `sat_frontier/tensor_contract.py` supporting NumPy einsum, PyTorch einsum (CPU/GPU), and heuristic min-degree bucket elimination; unit-tested (4 tests). Executed 72 runs across 18 instances in `evidence/tensor-study-001/` with 100% exact oracle agreement. Bucket elimination demonstrated a 6.2x median speedup over global einsum path optimization. Documented in `docs/TENSOR_CONTRACTION_REPORT.md` and verified by `verify_evidence.py`.
- Dual Cut-Based Reliability Compilation (`to_cut_cnf`): Implemented in `sat_frontier/cut_compiler.py`, compiling two-terminal connectivity directly over minimal $s-t$ cuts without auxiliary path indicators, reducing search nodes by up to 122x on bottleneck networks.
- Hypothesis H9 Dual Cut-Based Compilation Campaign: Preregistered, unit-tested (5 tests in `tests/test_cut_compiler.py`), and executed across 48 runs in `evidence/cut-wmc-001/` over 24 topologies. Proved that Dual Cut monotone CNF compilation shatters the structural hardness cliff identified in the EPYC campaign, solving `grid_3x7` in 2.13s (from >600s timeout) and `grid_2x11` in 0.12s, with 100% exact rational agreement across all 12 mutually solved instances and 0 mismatches. Fully documented in `docs/CUT_COMPILATION_REPORT.md` and verified by `verify_evidence.py`.
- High-Concurrency Cut Cube Lookahead Campaign: Executed across 36 runs in `evidence/cut-cube-001/` over 12 hardness-boundary topologies with 20 workers. Demonstrated that deeper lookahead (depth 6, 64 cubes) overcomes node budget exhaustion, solving `grid_3x8` in 3.26s, `grid_3x9` in 11.52s (1.4M nodes), and `grid_4x6` in 11.06s (1.3M nodes) with 19/19 cross-depth exact invariant checks matching. Fully documented in `evidence/cut-cube-001/SUMMARY.md` and verified by `verify_evidence.py`.
- Commercialization Engine (P0-P1): Implemented production Enterprise Reliability & SLA Audit SDK in `sat_frontier/enterprise/` (`topology.py`, `metrics.py`, `engine.py`, `report.py`, `cli.py`), providing exact Birnbaum sensitivity indexing $I_B(e) = \frac{\partial R}{\partial p_e}$, $N$-nines and downtime calculation, single point of failure (SPOF) detection, and markdown/JSON audit generators. Evaluated across 5 production topologies in `evidence/commercial-benchmarks-001/` with sub-250ms solving times and 100% exact rational solutions. Documented in `docs/ENTERPRISE_SDK_GUIDE.md` and `docs/SLA_AUDIT_SPECIFICATION.md`.
- Hypothesis H10 Multi-Terminal (K-Terminal) Network Reliability: Generalized Menger cut duality to multi-terminal ($K \ge 2$) and all-terminal ($K = V$) reliability in `sat_frontier/k_cut_compiler.py`, completely eliminating Steiner tree enumeration. Executed 24 benchmark instances in `evidence/k-terminal-wmc-001/` with 17/17 independent brute force oracle checks matching (100% exact rational agreement). Solved 4-corner multi-terminal `grid_4x4` (16 nodes, 24 edges, 506 cuts) in 0.39s and integrated multi-terminal auditing into `EnterpriseReliabilityEngine.audit_multi_terminal`. Documented in `docs/K_TERMINAL_REPORT.md` and `docs/K_TERMINAL_PREREGISTRATION.md`.
- Hypothesis H11 Algebraic Model Counting over $\mathbb{Z}[x]$: Implemented polynomial weighted model counting in `sat_frontier/poly_wmc.py` evaluating complete closed-form reliability polynomials $P(x) = \sum c_k x^k$, continuous derivatives $\chi(p) = \frac{dR}{dp}$, and exact finite-size percolation phase transitions $p_c$. Executed 24 benchmark instances in `evidence/poly-wmc-001/` with 17/17 independent brute force oracle checks matching (100% exact integer coefficient equality). Solved `grid_4x5` (degree 31, 1,353 clauses) in 2.05s via DLCS heuristic. Documented in `docs/POLYNOMIAL_WMC_REPORT.md`.
- Hypothesis H12 Dual Dicut Monotone CNF Compilation: Formulated and proved the directed cut duality theorem for directed two-terminal reliability ($s \leadsto t$) in `sat_frontier/dicut_compiler.py`, eliminating simple path enumeration and MTZ subtour elimination bloat with strictly $|A|$ variables. Executed 24 benchmark instances in `evidence/dicut-wmc-001/` across layered DAGs, cyclic meshes, barbells, and enterprise systems with 18/18 independent oracle checks matching (100% exact rational agreement). Documented in `docs/DICUT_RELIABILITY_REPORT.md`.
- Hypothesis H13 Dual Mixed-Cut Monotone CNF Compilation: Formulated and proved that internal node-splitting ($v \mapsto (v_{\text{in}}, v_{\text{out}})$ with operational probability $q_v$) transforms mixed node-and-edge failure network reliability into directed cut reachability in split graph $G^*$, yielding exact monotone CNF formulas with zero auxiliary variables. Implemented in `sat_frontier/mixed_cut_compiler.py`, unit-tested (7 tests), and evaluated across 24 benchmark instances in `evidence/mixed-wmc-001/` with 16/16 independent brute force oracle checks matching (100% exact rational agreement) and sub-290ms latency. Documented in `docs/MIXED_RELIABILITY_REPORT.md` and `docs/MIXED_RELIABILITY_PREREGISTRATION.md`.
- All-Pairs SLA Matrix & Centrality Engine: Implemented complete network-wide pairwise availability engine in `sat_frontier/enterprise/all_pairs.py`. Computes all $\binom{|V|}{2}$ pairwise SLA availabilities, identifies worst-case SLA bottleneck pairs, calculates Network Diameter Reliability $R_{\text{min}}$, computes failure-aware node centrality $C_R(v) = \frac{1}{|V|-1}\sum_{u \ne v} R(v, u)$, and generates ANSI terminal heatmaps and Markdown SLA reports. Integrated into `sat_frontier/enterprise/engine.py` (`audit_all_pairs`) and CLI (`--all-pairs`, `--demo-subsea`).
- Hypothesis H14 Dual SRRG-Cut Monotone CNF Compilation: Formulated and proved the Shared-Risk Resource Group (SRRG / Fate-Sharing) cut duality theorem for correlated multi-failure network reliability in `sat_frontier/srrg_compiler.py`. Compiled arbitrary physical risk mappings directly to monotone CNF clauses over risk survival variables alone with zero auxiliary routing variables. Executed 24 benchmark instances in `evidence/srrg-wmc-001/` across optical rings, subsea meshes, cloud VPCs, and staged pipeline corridors with 22/22 independent oracle checks matching (100% exact rational agreement) and sub-0.15ms solving latency. Documented in `docs/SRRG_RELIABILITY_REPORT.md` and `docs/SRRG_RELIABILITY_PREREGISTRATION.md`.
- High-Core AMD EPYC Frontier Cut Scaling Campaign: Pre-compiled 10 frontier benchmark instances (`grid_3x8..3x11`, `grid_4x5..4x7`, `grid_5x5`, `barbell_6_3_6`, `chvatal`) in `instances/epyc-cut-frontier/` with exact literal weights. Created turnkey Linux runner `scripts/run_epyc_cut_campaign.sh`, multi-depth batch harness `scripts/run_epyc_cut_campaign.py`, and comprehensive deployment specification `docs/EPYC_CUT_CAMPAIGN_SPECIFICATION.md`.
- Hermes GPT-6.1 Terra Directive for AMD EPYC: Authored turnkey execution directive in `docs/HERMES_TERRA_EPYC_DIRECTIVE.md` for autonomous commission of the 64-core AMD EPYC server (168 GB RAM), including NUMA memory interleaving, automated verification checks, and cross-depth invariants.
- Hypothesis H15 Continuous Temporal Network Reliability & Exact Closed-Form MTTF: Formulated and proved the Exact Algebraic MTTF Integration Theorem: $\text{MTTF} = \sum_{j=1}^m \frac{a_j}{j \lambda}$, evaluating exact rational lifetime moments directly from monomial expansions of $P(x) \in \mathbb{Z}[x]$ in microseconds without Monte Carlo sampling. Implemented in `sat_frontier/temporal_reliability.py`, unit-tested (7 tests), and executed across 24 benchmark instances in `evidence/temporal-wmc-001/` with 24/24 independent composite Simpson quadrature checks matching within $10^{-4}$ relative tolerance. Documented in `docs/TEMPORAL_RELIABILITY_REPORT.md` and `docs/TEMPORAL_RELIABILITY_PREREGISTRATION.md`.
- Hypothesis H16 Capacitated Network Flow Reliability: Formulated and proved the Capacitated Dual Cut Duality Theorem showing that $\mathbb{P}(\text{MaxFlow} \ge D)$ compiles directly into monotone positive clauses over physical edge variables alone with strictly $|E|$ variables and zero auxiliary flow variables. Implemented in `sat_frontier/capacitated_compiler.py`, unit-tested (7 tests), and executed across 24 benchmark instances in `evidence/capacitated-wmc-001/` with 24/24 independent Dinic max-flow truth-table oracle checks matching with 100% exact rational precision and sub-0.2ms mean latency. Documented in `docs/CAPACITATED_RELIABILITY_REPORT.md` and `docs/CAPACITATED_RELIABILITY_PREREGISTRATION.md`.
- Release v0.2.7: Built and cryptographically pinned distribution archive `artifacts/release/sat-frontier-v0.2.7.zip` (2,242 files, 8,897,269 bytes, SHA-256: `79b61e06d7b035fab7426f8f2b2d30da5df354983f321519e95f78b730bd1272`).
- Enterprise Topology Importers: Implemented universal zero-dependency importers in `sat_frontier/enterprise/importers.py` supporting GraphML, GML, NetworkX/Cytoscape JSON, and CSV/TSV link inventories; integrated into Enterprise CLI and SDK.
- Internet Topology Zoo Benchmark Suite: Curated and validated standard carrier backbones in `instances/topologies/` (Abilene GraphML, Internet2 GML, BellSouth CSV, Colt JSON, GEANT GraphML), running sub-100ms full SLA audits.
- Unified Research Monograph & LaTeX Paper: Authored comprehensive academic paper in `docs/RESEARCH_PAPERS/SAT_FRONTIER_UNIFIED_DUALITY.md` and publication-grade LaTeX paper `docs/RESEARCH_PAPERS/SAT_FRONTIER_UNIFIED_DUALITY.tex` unifying all 8 Dual Cut Duality Theorems, proofs, complexity bounds, 18-suite empirical results, and formal audit findings on OpenAI's ETH refutation.
- Local integrated suite: 154 unit and metamorphic tests passed with cross-platform Windows and Linux support. All 18 empirical evidence suites pass (2,750 total verified runs). Unified master verifier `verify_all_evidence.py` confirms 100% integrity across all suites in 14.26 seconds.

## Blocked, failed and untested

- GitHub-hosted correctness CI attempted on bootstrap revision `5bf97406188d7a2da8dc23b9ba008c6dee2caa31` but GitHub did not start the job: account payments failed or spending limit must be increased. See https://github.com/Hardonian/SAT-Frontier/actions/runs/40697617863 . No billing change was made. After the owner fixes billing, rerun the latest main correctness run:

  `id=$(GH_CONFIG_DIR=/home/scott/.config/gh gh run list --repo Hardonian/SAT-Frontier --workflow correctness --branch main --limit 1 --json databaseId --jq '.[0].databaseId'); test -n "$id" && GH_CONFIG_DIR=/home/scott/.config/gh gh run rerun "$id" --repo Hardonian/SAT-Frontier`
- Upstream Lean target exited 137 / timed out with 11.9 GB memory peak before kernel check or `#print axioms`; Milestone M4 extraction remains gated. Pinned in `evidence/eth-audit/continuation/lean_audit_blocker_2026-10-28.json`.
- Upstream theorem kernel check remains untested due to Lean 4 memory ceiling.
- Measured RSS contains an inherited/startup high-water floor and should not be used as comparative memory evidence; RLIMIT_AS is not aggregate RSS. Bandit reports low-severity trust-boundary findings, no medium or high findings; run only trusted external binaries.

## Recheck

```bash
python3 -m unittest discover -s tests -v
python3 verify_all_evidence.py
python3 -m sat_frontier.enterprise.cli --demo-cloud
python3 -m sat_frontier.enterprise.cli --demo-subsea --all-pairs
python3 -m sat_frontier solve examples/two-components.cnf
python3 verify_policy_evidence.py
python3 verify_holdout_evidence.py
python3 verify_evidence.py evidence/separator-study-001
python3 verify_evidence.py evidence/scaling-benchmark-001
python3 verify_evidence.py evidence/wmc-reliability-001
python3 verify_evidence.py evidence/tensor-study-001
python3 verify_evidence.py evidence/cut-wmc-001
python3 verify_evidence.py evidence/cut-cube-001
python3 verify_epyc_evidence.py evidence/epyc-cube-001 evidence/epyc-cube-002
python3 verify_evidence.py evidence/commercial-benchmarks-001
python3 verify_evidence.py evidence/k-terminal-wmc-001
python3 verify_evidence.py evidence/poly-wmc-001
python3 verify_evidence.py evidence/dicut-wmc-001
python3 verify_evidence.py evidence/mixed-wmc-001
python3 verify_evidence.py evidence/srrg-wmc-001
python3 verify_evidence.py evidence/temporal-wmc-001
python3 verify_evidence.py evidence/capacitated-wmc-001
python3 scripts/run_epyc_cut_campaign.py --dry-run
python3 verify_evidence.py evidence/v02-integrated-development-001 --source-root evidence/v02-integrated-development-001/source-snapshot
```

For the original smoke evidence, extract the preserved bootstrap ZIP into a new directory and pass the extracted v0.1 project directory as `--source-root`; see `docs/INDEPENDENT_BASELINE.md`. Without `SAT_FRONTIER_SHARPSAT` the actual external-binary integration test is explicitly skipped. The manifest records source hashes and dirty state at campaign time. Do not overwrite existing evidence directories.

## Blocked, failed and untested

- GitHub-hosted correctness CI attempted on bootstrap revision `5bf97406188d7a2da8dc23b9ba008c6dee2caa31` but GitHub did not start the job: account payments failed or spending limit must be increased. See https://github.com/Hardonian/SAT-Frontier/actions/runs/40697617863 . No billing change was made. After the owner fixes billing, rerun the latest main correctness run:

  `id=$(GH_CONFIG_DIR=/home/scott/.config/gh gh run list --repo Hardonian/SAT-Frontier --workflow correctness --branch main --limit 1 --json databaseId --jq '.[0].databaseId'); test -n "$id" && GH_CONFIG_DIR=/home/scott/.config/gh gh run rerun "$id" --repo Hardonian/SAT-Frontier`
- Upstream Lean target exited 137 / timed out with 11.9 GB memory peak before kernel check or `#print axioms`; Milestone M4 extraction remains gated. Pinned in `evidence/eth-audit/continuation/lean_audit_blocker_2026-10-28.json`.
- Upstream theorem kernel check remains untested due to Lean 4 memory ceiling.
- Measured RSS contains an inherited/startup high-water floor and should not be used as comparative memory evidence; RLIMIT_AS is not aggregate RSS. Bandit reports low-severity trust-boundary findings, no medium or high findings; run only trusted external binaries.

## Recheck

```bash
python3 -m unittest discover -s tests -v
python3 verify_all_evidence.py
python3 -m sat_frontier.enterprise.cli --demo-cloud
python3 -m sat_frontier.enterprise.cli --demo-subsea --all-pairs
python3 -m sat_frontier solve examples/two-components.cnf
python3 verify_policy_evidence.py
python3 verify_holdout_evidence.py
python3 verify_evidence.py evidence/separator-study-001
python3 verify_evidence.py evidence/scaling-benchmark-001
python3 verify_evidence.py evidence/wmc-reliability-001
python3 verify_evidence.py evidence/tensor-study-001
python3 verify_evidence.py evidence/cut-wmc-001
python3 verify_evidence.py evidence/cut-cube-001
python3 verify_epyc_evidence.py evidence/epyc-cube-001 evidence/epyc-cube-002
python3 verify_evidence.py evidence/commercial-benchmarks-001
python3 verify_evidence.py evidence/k-terminal-wmc-001
python3 verify_evidence.py evidence/poly-wmc-001
python3 verify_evidence.py evidence/dicut-wmc-001
python3 verify_evidence.py evidence/mixed-wmc-001
python3 verify_evidence.py evidence/srrg-wmc-001
python3 scripts/run_epyc_cut_campaign.py --dry-run
python3 verify_evidence.py evidence/v02-integrated-development-001 --source-root evidence/v02-integrated-development-001/source-snapshot
```

For the original smoke evidence, extract the preserved bootstrap ZIP into a new directory and pass the extracted v0.1 project directory as `--source-root`; see `docs/INDEPENDENT_BASELINE.md`. Without `SAT_FRONTIER_SHARPSAT` the actual external-binary integration test is explicitly skipped. The manifest records source hashes and dirty state at campaign time. Do not overwrite existing evidence directories.

For the original smoke evidence, extract the preserved bootstrap ZIP into a new directory and pass the extracted v0.1 project directory as `--source-root`; see `docs/INDEPENDENT_BASELINE.md`. Without `SAT_FRONTIER_SHARPSAT` the actual external-binary integration test is explicitly skipped. The manifest records source hashes and dirty state at campaign time. Do not overwrite existing evidence directories.
